import os, sys, zlib, json
from pathlib import Path

SIG2KEY = {
    bytes.fromhex("9DC7"): bytes.fromhex("E55B4ED1"),
}

# ✅ Fixed root path for log.json
LOG_ROOT = Path("LOG")  # yaha log.json rahega

def is_sig_at(data: bytes, i: int):
    if i + 2 > len(data):
        return None
    return SIG2KEY.get(data[i:i+2], None)

def xor_decode_with_feedback(data: bytes) -> bytes:
    out = bytearray()
    key = None
    seg_pos = 0
    seg_start_out = 0
    i = 0
    while i < len(data):
        k = is_sig_at(data, i)
        if k is not None:
            key = k
            seg_pos = 0
            seg_start_out = len(out)
        if key is not None:
            if seg_pos < 4:
                o = data[i] ^ key[seg_pos]
            else:
                fb_index = seg_start_out + (seg_pos - 4)
                o = data[i] ^ out[fb_index]
            out.append(o)
            seg_pos += 1
        else:
            out.append(data[i])
        i += 1
    return bytes(out)

def xor_reencode_from_original(encoded_original: bytes, decoded_modified: bytes) -> bytes:
    assert len(encoded_original) == len(decoded_modified)
    out_enc = bytearray()
    key = None
    seg_pos = 0
    seg_start_out = 0
    for i in range(len(decoded_modified)):
        k = is_sig_at(encoded_original, i)
        if k is not None:
            key = k
            seg_pos = 0
            seg_start_out = i
        if key is not None:
            if seg_pos < 4:
                b = decoded_modified[i] ^ key[seg_pos]
            else:
                fb_index = seg_start_out + (seg_pos - 4)
                b = decoded_modified[i] ^ decoded_modified[fb_index]
            out_enc.append(b)
            seg_pos += 1
        else:
            out_enc.append(decoded_modified[i])
    return bytes(out_enc)

def repack(pak_file: Path, repack_dir: Path):
    manifest_path = LOG_ROOT / "log.json"   # ✅ Always use root log.json
    if not manifest_path.exists():
        print(f"❌ log.json not found at {manifest_path}")
        return

    data_enc_orig = pak_file.read_bytes()
    print("🔓 Decoding XOR...")
    decoded = bytearray(xor_decode_with_feedback(data_enc_orig))

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    entries = manifest.get("entries", [])

    patched_cnt = 0
    skipped_cnt = 0

    for e in entries:
        relpath = e["relpath"]
        start = int(e["start"])
        consumed = int(e["consumed"])

        src_edit = repack_dir / relpath
        if not src_edit.exists():
            continue

        raw = src_edit.read_bytes()
        comp = zlib.compress(raw, level=9)

        if len(comp) <= consumed:
            decoded[start:start+len(comp)] = comp
            if len(comp) < consumed:
                decoded[start+len(comp):start+consumed] = b"\x00" * (consumed - len(comp))
            patched_cnt += 1
            print(f"✔ Reimport {relpath} | {len(comp)} bytes <= slot {consumed}")
        else:
            skipped_cnt += 1
            print(f"⚠ Skipped {relpath} | {len(comp)} > slot {consumed}")

    print(f"✅ Reimport complete: {patched_cnt} replaced, {skipped_cnt} skipped.")

    print("🔒 Re-encoding XOR...")
    encoded_final = xor_reencode_from_original(data_enc_orig, bytes(decoded))

    pak_file.write_bytes(encoded_final)
    print(f"🎉 Repack successful → {pak_file} (size {len(encoded_final)} bytes)")

def main():
    if len(sys.argv) != 3:
        print(f"Usage: python {sys.argv[0]} input.pak repack_dir")
        sys.exit(1)

    pak_file = Path(sys.argv[1])
    repack_dir = Path(sys.argv[2])

    if not pak_file.exists():
        print(f"❌ Pak file not found: {pak_file}")
        sys.exit(1)
    if not repack_dir.exists():
        print(f"❌ Repack dir not found: {repack_dir}")
        sys.exit(1)

    repack(pak_file, repack_dir)

if __name__ == "__main__":
    main()