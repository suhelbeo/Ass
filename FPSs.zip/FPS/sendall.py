import os
import shutil
import subprocess
import threading
from telegram import Bot, Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackContext
import telegram

# --- Config Section ---
BOT_TOKEN = '7868123670:AAE4X8i9NR10lt6AliDSgBPCwdrgxsAkU6M'
CHANNEL_USERNAME = '@FPS_UNLOCK'  # Your Channel Username
BOT_OWNER_ID = 1680864482  # <-- Yaha apna Telegram user ID daalo (number)

# --- Helper Functions ---

# Save user ID into a file
def save_user_id(user_id):
    try:
        if not os.path.exists('users.txt'):
            with open('users.txt', 'w') as f:
                f.write('')

        with open('users.txt', 'r') as f:
            existing_ids = set(f.read().splitlines())

        if str(user_id) not in existing_ids:
            with open('users.txt', 'a') as f:
                f.write(str(user_id) + '\n')
    except Exception as e:
        print(f"Error saving user ID: {e}")

# Check user membership
def is_user_member(bot, user_id):
    try:
        member = bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id)
        if member.status in ['member', 'administrator', 'creator']:
            return True
        else:
            return False
    except telegram.error.TelegramError:
        return False

# Replace work function
def replace_string_in_files(device_name, source_folder, output_folder, pak_file_path):
    device_name_folder = device_name.replace(' ', '_')
    search_string = 'SM-S911U|SM-S911U1|SM-S911W|SM-S911N|SM-S9110|SM-S911E'
    max_length = len(search_string)
    device_with_pipe = device_name + '|'

    if len(device_with_pipe) > max_length:
        return None

    output_dir = os.path.join(output_folder, device_name_folder)
    os.makedirs(output_dir, exist_ok=True)

    for file_name in os.listdir(source_folder):
        file_path = os.path.join(source_folder, file_name)
        if os.path.isfile(file_path):
            with open(file_path, 'rb') as file:
                data = file.read()
            if search_string.encode() in data:
                start_index = data.find(search_string.encode())
                pad_char = b'|'
                replacement = device_with_pipe.encode() + pad_char * (max_length - len(device_with_pipe))
                modified_data = data[:start_index] + replacement + data[start_index + max_length:]
                output_file_path = os.path.join(output_dir, file_name)
                with open(output_file_path, 'wb') as output_file:
                    output_file.write(modified_data)

    pak_destination_path = os.path.join(output_dir, os.path.basename(pak_file_path))
    try:
        shutil.copy2(pak_file_path, pak_destination_path)
    except FileNotFoundError:
        return None

    try:
        command = f'python3 reakbot.py "{pak_destination_path}" "{output_dir}"'
        subprocess.run(command, shell=True, check=True)
    except subprocess.CalledProcessError:
        return None

    return pak_destination_path

# --- Command Handlers ---

# /start command
def start(update: Update, context: CallbackContext):
    user_id = update.effective_user.id

    save_user_id(user_id)

    if is_user_member(context.bot, user_id):
        update.message.reply_text("You are already a member! Welcome.\n/bgmi")
    else:
        join_button = InlineKeyboardButton("Join Our Channel", url=f"https://t.me/FPS_UNLOCK")
        keyboard = [[join_button]]
        reply_markup = InlineKeyboardMarkup(keyboard)

        update.message.reply_text(
            "You must join our channel to use this bot.",
            reply_markup=reply_markup
        )

# Process FPS command
def process_fps_command(update: Update, context: CallbackContext, device_name):
    source_folder = 'OG'
    output_folder = 'MODDED'
    pak_file_path = 'game_patch_4.0.0.20332.pak'

    update.message.reply_text(f'Processing started for: {device_name}... Please wait.')

    result_file = replace_string_in_files(device_name, source_folder, output_folder, pak_file_path)

    if result_file and os.path.exists(result_file):
        try:
            with open(result_file, 'rb') as f:
                update.message.reply_document(document=f)
            os.remove(result_file)
        except OSError as e:
            update.message.reply_text(f"Error opening the result file: {e}")
    else:
        update.message.reply_text('Something went wrong. Please check device name or try again.')

# /fps command
def fps_command(update: Update, context: CallbackContext):
    user_id = update.effective_user.id

    if not is_user_member(context.bot, user_id):
        join_button = InlineKeyboardButton("Join Our Channel", url=f"https://t.me/FPS_UNLOCK")
        keyboard = [[join_button]]
        reply_markup = InlineKeyboardMarkup(keyboard)

        update.message.reply_text(
            "You must join our channel to use this bot.",
            reply_markup=reply_markup
        )
        return

    if not context.args:
        update.message.reply_text('Please provide device model Usage:\n/bgmi your_device_model')
        return

    device_name = ' '.join(context.args)

    thread = threading.Thread(target=process_fps_command, args=(update, context, device_name))
    thread.start()

# /sendall command (admin only)
def sendall(update: Update, context: CallbackContext):
    user_id = update.effective_user.id

    if user_id != BOT_OWNER_ID:
        update.message.reply_text("You are not authorized to use this command.")
        return

    if not context.args:
        update.message.reply_text("Usage: /sendall Your Message Here")
        return

    message_text = ' '.join(context.args)

    if not os.path.exists('users.txt'):
        update.message.reply_text("No users found.")
        return

    with open('users.txt', 'r') as f:
        user_ids = set(f.read().splitlines())

    count = 0
    for uid in user_ids:
        try:
            context.bot.send_message(chat_id=int(uid), text=message_text)
            count += 1
        except Exception as e:
            print(f"Failed to send to {uid}: {e}")

    update.message.reply_text(f"Message sent to {count} users.")

# --- Main Bot Start ---
def main():
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler('start', start))
    dp.add_handler(CommandHandler('bgmi', fps_command))
    dp.add_handler(CommandHandler('sendall', sendall))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()